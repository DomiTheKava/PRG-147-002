function myFunction2() {
    document.getElementById("start").innerHTML = "Changed from a function in the external section"
}